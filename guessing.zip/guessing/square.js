const prompt = require('prompt-sync')();
let board = ["1","2","3","4","5","6","7","8","9"];
function table(){
  console.log(`
      ${board[0]} | ${board[1]} | ${board[2]}
       -------
      ${board[3]} | ${board[4]} | ${board[5]}
       -------
      ${board[6]} | ${board[7]} | ${board[8]}`
      );
}
const tictacToe = function() {
  let slotOne = true;
  let slotTwo = true;
  

  for(let i = 0; i < 5; i++) {
    table();
    console.log("Please Pick one squares using the numbers:");
    userPick = prompt();
    let compPick = 1;
    if(userPick === board[0]) {
      slotOne = false;
      board.splice(0,1, "X");
      table();
    }
    console.log("Please Pick one squares using the numbers:");
    compPick = prompt();
    if (compPick === board[0]){
      slotOne = false;
      board.splice(0,1, "O");
      table();
    }
    if (compPick === board[1]){
      slotOne = false;
      board.splice(1,1, "O");
      table();
    }
    
  }

}
tictacToe();