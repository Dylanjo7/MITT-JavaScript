const prompt = require('prompt-sync')();

function isValid(maxVal){
	return (!isNaN(maxVal) && 
			(Number(maxVal) >= 10 && 
			 Number(maxVal) <= 99)
		   );
}

function getUserInput() {
	console.log("Welcome to the guessing game.\nEnter a maximum value between 10-99:");
	let maxVal = prompt();
	// if what the user entered is not a number between 10 and 99, 
	// keep asking them until they enter a valid input
	// if the user enters quit, end the game
	while(maxVal !== "quit" && !isValid(maxVal)) {
		console.log("Your input is invalid.");
		maxVal = prompt("Enter a maximum value between 10-99:");
	}
	if(maxVal === "quit") {
		console.log("I guess you don't really want to play. Bye");
	}
	return maxVal;
}

function main() {
	let maxValue = getUserInput();
	// if it is quit, we just stop doing stuff
	if(maxValue !== "quit") {
		console.log(maxValue);
		let secretNumberToGuess = Math.trunc((Math.random() * Number(maxValue)) + 1);
		// start the game
	}
}
main();

