// function calculateSum(arr) {
//   let sum = 0;
//   for (let i = 0; i < arr.length; i++) {
//     sum += arr[i];
//   }
//   return sum;
// }

// const numbers = [1, 2, 3, 4, 5];
// const result = calculateSum(numbers);
// console.log(`The sum of the numbers is: ${result}`);
// You needed to take out the = from the <=


// function calculateAverage(numbers) {
//   let sum = 0;
//   let average = 0;
  
//   for (let i = 0; i < numbers.length; i++) {
//     sum += numbers[i];
//   }

//   average = sum / numbers.length;
//   return average;
// }

// const numbers = [10, 20, 30, 40, 50];
// const averageValue = calculateAverage(numbers);
// console.log(`The average is: ${averageValue}`);

// // There was no return average;

// function findLargest(numbers) {
//   let largest = numbers[0];

//   for (let i = 0; i < numbers.length; i++) {
//     if (numbers[i] > largest) {
//       largest = numbers[i];
//     }
//   }
//   return largest;
// }

// const numbers = [12, 45, 7, 23, 56, 91, 8, 34];
// const largestNumber = findLargest(numbers);
// console.log(`The largest number is: ${largestNumber}`);
// // You forgot to make largest = to the number of numbers

// function getFullName(person) {
//   return person.firstName + " " + person.lastName;
// }

// const user = {
//   firstName: "John",
//   lastName: "Doe",
// };

// const fullName = getFullName(user);
// console.log(`The full name is: ${fullName}`);
// // I just added a space inbetween the name