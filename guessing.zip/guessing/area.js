const prompt = require('prompt-sync')();

function runPro() {
  console.log("Enter a Width:");
  let width = prompt();
  console.log("Enter a Height:");
  let height = prompt();

  if (!isNaN(width) && !isNaN(height)) {
    area = width * height;
    console.log("With",width, "as your Width and", height,"as your Height,",area,"will be your area!")
  }
  else {
    console.log("Wrong")
  }

  return area
}
runPro();