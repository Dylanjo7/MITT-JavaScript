
let prices = [1.23, 48.11, 90.11, 8.5, 9.99, 1.0, 1.1, 67.0];

console.log("Original Prices:", prices);
prices.splice(1,1, 2);
prices.splice(3,1, 4);
prices.splice(7,1, 6);

console.log("New Prices:", prices);


let arrayClone =[1, 5, 4, 19]; // returns a new array [1,5,4,19]
let clonedArray = [];
// arrayClone(['a', ['b', 'c'], 'd']); // returns a new array ['a', ['b', 'c'], 'd']
function clone() {
  console.log(arrayClone);
  for(let i = 0; i < arrayClone.length; i++) {
    clonedArray[i] = arrayClone[i];
  }
  console.log(clonedArray)
}
clone();
let userInput = 4;
function returns(){
  let first = [7, 9, 0, -2]; // returns 7
  let newArray = [];
  
  // first([7, 9, 0, -2], 3); // returns [7, 9, 0]
  console.log("Please Enter a Number:");
  for(let i = 0; i < userInput; i++){
    newArray[i] = first[i];
  }
  console.log(newArray)
  
}
returns();