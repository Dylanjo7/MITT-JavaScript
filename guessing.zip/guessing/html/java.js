var myButton = document.getElementById("myButton");
var clicked = false;
document.addEventListener("DOMContentLoaded", function(){

});

myButton.addEventListener("click", function() {
  var newElement = document.createElement("div");
  document.body.appendChild(newElement);

  if(!clicked) {
    myButton.innerText = "Button Clicked!";
    document.body.style.backgroundColor = "red";
  } else {
    myButton.innerText = "Click Me Again";
    document.body.style.backgroundColor = "blue";
  }
  clicked = !clicked;
});