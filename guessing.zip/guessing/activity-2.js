const prompt = require("prompt-sync")();

const questions = [
  "What is the name of SpongeBob's pet snail?",
  "Where does SpongeBob work?",
  "Who is SpongeBob's best friend?",
  "What is the name of SpongeBob's greedy boss at the Krusty Krab?",
  "What is the name of the underwater city where SpongeBob lives?",
  "What is Squidward's last name?"
]

const answers = [
  "gary",
  "the krusty krab",
  "patrick star",
  "mr. krabs",
  "bikini bottom",
  "tentacles"
]

let final = 0;
for(let i = 0;  i < questions.length; i++) {
  console.log(questions[i]);
  console.log("Enter your Answer:");
  let userAns = (prompt());

  if(userAns.toLowerCase() === answers[i]){
    console.log("Correct + 1");
    final++;
  }
  if(userAns.toLowerCase() !== answers[i]) {
    console.log("Wrong - 1");
    final--;
  }
}
console.log("Your Score is wrong - 1, and correct + 1");
console.log("Your Score is:", final);

