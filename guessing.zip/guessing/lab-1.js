const prompt = require("prompt-sync")();

function concatenation (num, str) {
  let result = num + str;
  console.log("Result:", result);
  console.log("Typeof", typeof result);
}
function main() {

  console.log("Enter a Number");
  let userNum = Number(prompt());
  console.log("Enter a String");
  let userStr = (prompt());

  concatenation();
}
main();