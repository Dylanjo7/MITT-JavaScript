const prompt = require('prompt-sync')();

function main() {
  console.log("Welcome to wishlist builder. Enter LIST to view list, QUIT to end.");
  console.log("Enter an item to add to your wishlist:");
  let item = prompt();
  let wishlist = [];
  if(item.toUpperCase !== "QUIT") {
    if(item.toUpperCase === "LIST") {
      console.log("Here is your list:");
      console.log(wishlist);
      console.log("Welcome to wishlist builder. Enter LIST to view list, QUIT to end.");
    }
    wishlist.push(item);
    console.log(wishlist.length);
    console.log("Item Added. Enter another item to add to your wishlist:")
    item = prompt();
  }

  console.log("Bye");
  console.log("Program End");
}
main();