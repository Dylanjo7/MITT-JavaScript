const prompt = require('prompt-sync')();
// creates the inventory has some pre set ones as examples
let inventory = {"apple": 3, "sword": 1};

// better way of doing console.log with variables
// https://stackoverflow.com/questions/16600925/how-can-i-add-a-variable-to-console-log

// this function takes in the item and count from the addInventory function and 
function addItem(item, count) {
  // makes the item in the inventory = the count of the (ex apple) + the new count from user. The "|| 0" is for if you are adding a new item then if it does not exist it just adds the count to 0
  inventory[item] = (inventory[item] || 0) + count;
  console.log(`Item added: ${item}`);
}

function deleteItem(item, count) {
  // to make sure that the item the user is deleting is actually a item
  if (inventory[item]) {
    // this makes sure that the count is less then the number of items you have, otherwise if you have 5 apples and you delete 6 you will have -1 so this stops that
    if (count <= inventory[item]) {
      // This actually deletes some of the items so if the count is 4 and you have 10 it would do 10-4 and you would have 6 left
      inventory[item] -= count;
      // this is when the checks if you have 0 left of an item so if you have 2 apples and delete 2 then it would fully delete the item from the inventory
      console.log(`Item deleted ${count} ${item}s from your inventory`);
      if (inventory[item] === 0) {
        delete inventory[item];
        console.log(`Item fully deleted from your inventory: ${item}`);
      }
    } else {
      console.log(`You cannot delete more items than available for ${item}`);
    }
  } else {
    console.log(`Item not found: ${item}`);
  }
}

// READ!!!
// this function is just becasue i like being able to pick how many of something I wanted to delete, but was not sure if marked would be taken off so I remade it to delete the item no matter the count.

// function deleteFullItem(item) {
//   if (inventory[item]) {
//     delete inventory[item];
//     console.log(`Item deleted: ${item}`);
//   }
//   console.log(`Item not found: ${item}`);
// }

// this function gets called at the begining of the main loop in main
let enter = () => {
  // this asks the user for the input and returns the user input for later, while making the input lowercase
  let userInput = prompt("Enter a command (add, delete, show, exit):").toLowerCase();
  return userInput;
}

// this function shows the user the inventory
function showInventory(item, count) {
  console.log("Current Inventory:");

  // goes through each item in the inventory I learnt this better from https://www.freecodecamp.org/news/loop-through-arrays-javascript/
  for (item in inventory) {
    // takes the count from the the item in inventory
    count = inventory[item];

    console.log(`\t${item}: ${count}`);
  }

}

// this function asks the user for the item and the count of the item they would like to add
let addInventory = () => {
  let item = prompt("Enter the item to add: ");
  let count = prompt("How many would you like to add: ");
  // makes the item lowercase
  item = item.toLowerCase();
  // makes the count an integer or number so it will work as a number in the future otherwise there is errors
  count = parseInt(count);
  // calls the addItem function from before
  addItem(item, count);
}

// this function gets called when the user enters delete and asked for the item that wants to get deleted and how many
let deleteInventory = () => {
  let item = prompt("Enter the item to delete: ");
  let count = prompt("How many would you like to delete: ");
  // makes the count an integer or number so it will work as a number in the future otherwise there is errors
  item = item.toLowerCase();
  // calls the addItem function from before
  count = parseInt(count);
  // calls the deleteItem function
  deleteItem(item, count);
}

// this is the main function that calls most of the other functions and has the main game loop so if something break then it just restarts and this makes you able to exit as a user
function main() {
  // creates the gameLoop
  let gameLoop = true;

  // when the gameloop = true
  while (gameLoop) {
    // makes the userInput the output of the enter function
    let userInput = enter()
    
    // this checks for all of the options and calls the function based on the users input
    if (userInput === "show") {
      showInventory();
    } else if (userInput === "add") {
      addInventory();
    } else if (userInput === "delete") {
      deleteInventory();
    } else if (userInput === "exit") {
      // when the user enters exit it makes the gameLoop false so it exits the loop/program
      gameLoop = false;
    } else {
      console.log("Invalid command. Please try again.");
    }
  }
  console.log("Thanks for storing your stuff");
}
// calls the main function so the program can run
main();
