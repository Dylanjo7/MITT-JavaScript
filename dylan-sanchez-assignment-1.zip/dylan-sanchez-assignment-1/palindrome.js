const prompt = require('prompt-sync')();

// function that checks if it is a palindrome
function isPalindrome(stringInput) {
    // makes the input lowercase
    stringInput = stringInput.toLowerCase();
    //sets variables
    let reversedInput = "";
    // for loop that runs through the length of the string
    for(let i = 0; i < stringInput.length; i++) {
        // adds the letter of the string that we are looped on to reversedInput
        reversedInput = stringInput[i] + reversedInput;
    }
    // returns true of they are the same and if not blank
    return(reversedInput === stringInput && reversedInput !== "");
}

// Test cases
const testStrings = [
    "radar", 
    "apple", 
    "Racecar", 
    "java", 
    ""
];

// Expected outputs for the test cases
const expectedOutputs = [
    true,       // radar is a palindrome
    false,      // apple is not a palindrome
    true,       // Racecar is a palindrome NOTICE HOW 'R' AND 'r' ARE THE SAME
    false,      // Java is not a palindrome
    false       // Empty Strings are not palindromes
];

// Running the tests
testStrings.forEach((el, index) => {
    const result = isPalindrome(el);
    console.log(`Test ${index + 1}:`,el);
    console.log(`Expected Output: "${expectedOutputs[index]}"`);
    console.log(`Actual Output: "${result}"`);
    console.log(result === expectedOutputs[index] ? "Test Passed" : "Test Failed", '\n');
});
