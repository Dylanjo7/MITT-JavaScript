const prompt = require('prompt-sync')();

// function to ask the user to tell them how many sides on dice
function numSides() {
  while (true) {
    // asks user
    console.log("How Many Sides Are On Your Dice?");
    let sides = prompt();
     // makes sure dice number not less then 3
    if (sides < 3) {
      console.log("Sorry, that's not a valid size value. Please choose a positive number greater than 3.");
    } else {
      console.log("Thanks, Good Luck!!!");
      // returns sides from the function
      return Number(sides);
    }
  }
}

// this function rolls the dice and 
function rollDice(sides) {
  // declaring all of the variables
  let times = 1;
  let double = 0;
  let averageDice1 = 0;
  let averageDice2 = 0;

  //  a while loop that gets a random number using the sides the user has asked for on 2 die
  while (true) {
    // displays what roll this is
    console.log(times + ".");
    // picks random number from 1-user input/sides
    let randomDice_1 = Math.trunc((Math.random() * sides) + 1);
    // calculating average
    averageDice1 += randomDice_1;
    // displays that is die one and shows the rolled number
    console.log("Die #1:", randomDice_1);


    // picks random number from 1-user input/sides
    let randomDice_2 = Math.trunc((Math.random() * sides) + 1);
    // calculating average
    averageDice2 += randomDice_2;
    // displays that is die two and shows the rolled number
    console.log("Die #2:", randomDice_2);

    // adds 1 to times so we know for later and so the next roll shows what roll it is on
    times++;

    // is the numbers are both 1 it breaks the loop
    if (randomDice_1 === 1 && randomDice_2 === 1) {
      double++;
      break;
    }
    // if both numbers are the same it makes double add one so we know how many doubles we rolled
    if (randomDice_1 === randomDice_2) {
      double++;
    }
  }

  // because times starts at 1 we have to take off one or else the number of dice rolled count is 1 off
  times--;
 
  // if the times rolled is bigger then 10 it says finally and if not it says that was quick
  if (times > 10) {
    console.log("You got snake eyes! Finally! On try number:", times + "!");
  } else {
    console.log("You got snake eyes! That Was Quick. On try number:", times + "!");
  }
  
  // prints all of the information needed using the information from the functions
  console.log("Along the way you rolled doubles", double, "time!!");
  console.log("The Average for Dice 1 is:", averageDice1/times);
  console.log("The Average for Dice 2 is:", averageDice2/times);
}

function main() {
  // makes sides = sides in numSides
  const sides = numSides();
  // calls the rollDice Function with sides
  rollDice(sides);
}

// Run the main function
main();